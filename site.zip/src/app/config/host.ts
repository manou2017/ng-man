// const host = 'http://localhost/api_resto2/web/app_dev.php';
const host = 'http://localhost/resto3/api/web/app_dev.php';

export const urlApi = host;