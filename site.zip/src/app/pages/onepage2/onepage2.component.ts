import { Component, OnInit, ElementRef } from '@angular/core';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';

@Component({
    selector: 'app-onepage2',
    templateUrl: './onepage2.component.html',
    styleUrls: ['./onepage2.component.css']
})
export class Onepage2Component implements OnInit {
    isCollapsed: boolean;

    constructor() {
        this.isCollapsed = true;
    }

    ngOnInit() {
    }


}
