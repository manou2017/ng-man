export class Users {
    id: number;
    // username: string;
    // password: string;
    firstname: string;
    lastname: string;
    email: string;
}
