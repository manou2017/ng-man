import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatMenuModule } from '@angular/material';
// import { MatToolbarModule } from '@angular/material/toolbar';

@NgModule({
  imports: [MatButtonModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatMenuModule],
  exports: [MatButtonModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatMenuModule]
})
export class MaterialAppModule { }
